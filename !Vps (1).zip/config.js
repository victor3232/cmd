module.exports = {
    // ================= TELEGRAM CONFIG =================
    token: '8027347334:AAFM7_Gxmsfl1QX1d-XDD4f-aDDDNNjqSIk', 
    ownerid: 5894696119, 
    channelid: "@tokopicung", 
    urlown: 'https://t.me/sipicung',
    nameadmin: 'sipicung', 
  
    // ================= DIGITAL OCEAN CONFIG =================
    // API Key Anda sudah dimasukkan di sini
    apiDigitalOcean: 'dop_v1_7c5a3e8187a1f1ea606615b7f95115fe5a09af1e786cce17526c12ee2b22a11b', 
    passwordvps: 'VpsKamu69', // Password default untuk VPS yang dibuat
  
    // ================= DUITKU PAYMENT GATEWAY =================
    // ⚠️ WAJIB DIISI DENGAN DATA DARI DASHBOARD DUITKU ANDA
    duitkuMerchantCode: 'D20182', // Contoh: D12345
    duitkuApiKey: 'caa4719cecc7354ad8671daf42a44d82' // Contoh: 2838927392873abcde
};