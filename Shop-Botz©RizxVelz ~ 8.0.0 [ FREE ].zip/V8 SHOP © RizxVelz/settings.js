const fs = require('fs');
const chalk = require('chalk');

//~~~~~~~~~< GLOBAL SETTINGS >~~~~~~~~~\\

global.owner = ['6287866923778']
global.ownerUtama = "6287866923778"
global.namaOwner = "HITS SSH"
global.packname = 'Bot WhatsApp'
global.botname = 'HITS SSH'
global.botname2 = 'HITS SSH'
global.tempatDB = 'database.json'
global.pairing_code = true
//==============================================
global.linkOwner = "https://wa.me/6281246238773"
global.linkGrup = "https://t.me/hitsssh"
global.linkGrup2 = ""
global.linkSaluran = "https://whatsapp.com/channel/0029VbApu5I96H4ZOC6ChK0L"
global.idsaluran = ""
global.nameChannel = ""
global.linkytb = ''
global.sosmed = 'https://www.instagram.com/buciners.official?igsh=MTFtc2FoMDUzeGZrcw=='
//==============================================
// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3000
global.delayPushkontak = 6000
//==============================================
// Settings buy panel otomatis 
global.apibotnabzx = "NabzxBotz"
global.linkgcreseller = ""
global.merchantIdOrderKuota = "OK2331655"
global.apiOrderKuota = "998339817422291272331655OKCTFDE99E624891D6773E2D238C20D68DD6"
global.qrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214052376821155260303UMI51440014ID.CO.QRIS.WWW0215ID20253857722770303UMI5204541153033605802ID5921FREEN STORE OK23316556008SUKABUMI61054311162070703A016304BB57"
global.pinOrkut = ""
global.pwOrkut = ""
//==============================================
//
global.apido = "" // Api digital ocean
//==============================================
// Settings Api Panel Pterodactyl v1
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://tobrut.cjdw.tech"
global.apikey = "ptla_UwL4zjg4f7mtORuiyKu7pEBLiesryDgA4bOFTqRi0Qf" //ptla
global.capikey = "ptlc_U6lZN7x1Ekv2Iq6uVUKS0fKdVrpUNOGQqYiMVYEJw0q"
//==============================================
// Settings Api Panel Pterodactyl v2
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://"
global.apikeyV2 = "" //ptla
global.capikeyV2 = "" //ptlc
//==============================================

//==============================================
global.dana = "081230305611"
global.ovo = "081246238773"
global.gopay = "081246238773"
global.qris = "https://files.catbox.moe/0p0ij5.png"
// Settings Api Subdomain
global.subdomain = {
"rizxvelz.online": {
"zone": "8eac5133e31d86027c631df0bccb9a05", 
"apitoken": "JAU5FRMKWDykRWXQq3lre4PzRjJUVLgbw1VfcEnv"
},
"rizxvelz.shop": {
"zone": "13cc550eaa6101a6865886e7b0c4be30", 
"apitoken": "DJ8xCUS1EmaO_e5RaagMXpaPP5asaVH0Tc9DHD7w"
},
"kenz-host.my.id": {
"zone": "df24766ae8eeb04b330b71b5facde5f4", 
"apitoken": "fyaxLxD0jNONtMWK3AmnaiLkkWi5Wg3Y9h8nqJh6"
},
"panelkishop.web.id": {
"zone": "8f4812b3c78ca478b5d162b6cb35d1b3", 
"apitoken": "3Y0cW3cVVIhyeWHytqFEbGDrdWaAC-k8twOEeFP2"
},
"tokopanelkishop.biz.id": {
"zone": "d87d4f320d9902f31fbbcc5ee23fafe8", 
"apitoken": "D00akOLxF3qzBzpYBp5SbpaLTmwYeybNsyAcDfiB"
},
"rikionline.shop": {
"zone": "082ec80d7367d6d4f7c52600034ac635", 
"apitoken": "r3XUyNYtxNQYwZtGUIAChRqe0uTzwV4eVO7JpJ_l"
}
}

global.mess = {
	owner: " *ᴋʜᴜsᴜs ᴏᴡɴᴇʀ* ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ ʙᴀɴɢ HITS SSH",
	admin: " *ᴋʜᴜsᴜs ᴀᴅᴍɪɴ* ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴀᴅᴍɪɴ ʙᴀɴɢ HITS SSH",
	botAdmin: " *ʙᴏᴛ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ* ғɪᴛᴜʀ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ʙᴏᴛ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ",
	group: " *ᴋʜᴜsᴜs ɢʀᴜᴘ* ғɪᴛᴜʀ ɴʏᴀ ᴋʜᴜsᴜs ᴅɪ ɢʀᴏᴜᴘ",
	private: " *ᴋʜᴜsᴜs ᴄʜᴀᴛ ᴘʀɪᴠᴀᴛᴇ* ғɪᴛᴜʀ ɴʏᴀ ᴋʜᴜsᴜs ᴘʀɪᴠᴀᴛᴇ",
	prem: " *ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ* ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ",
}
//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});