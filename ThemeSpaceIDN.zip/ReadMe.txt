  ____                       ___ ____  _   _ 
 / ___| _ __   __ _  ___ ___|_ _|  _ \| \ | |
 \___ \| '_ \ / _` |/ __/ _ \| || | | |  \| |
  ___) | |_) | (_| | (_|  __/| || |_| | |\  |
 |____/| .__/ \__,_|\___\___|___|____/|_| \_|
       |_|                                   


Thank you for purchasing my SpaceIDN template.

Please follow the steps below for installation:

1. paste folder pterodactyl dari theme ke /var/www/

2. silakan tunggu pemindahan theme

3. setelah keinstall buka console menggunakan juice ssh/putty/termius dan ikutin command di bawah:
| cd /var/www/pterodactyl
| yarn add react-feather
| php artisan migrate
| > yes
| yarn build:production
| php artisan view:clear

4. setelah itu bisa kalian ubah theme di admin panel > settings > theme.


Setelah diubah kalian run ke 2 commands di bawah:
| cd /var/www/pterodactyl
| yarn build:production