/*
[+] ============================== [+]
BASE BY @wannoffc
ADD FITUR : RuztanXD ( Si Pemula ygy )

Tq
ALLAH
PENGGUNA BOT
WANNOFC
RUZTANXD

#MAAF KLO ADA YG KURANG INTINYA YQ ALL

JANGAN DI HAPUS SU HARGAI CREDITS DIKIT
*/


require("./RuztanXD")