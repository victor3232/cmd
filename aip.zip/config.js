/*
[+] ============================== [+]
BASE BY @wannoffc
ADD FITUR : RuztanXD ( Si Pemula ygy )

Tq
ALLAH
PENGGUNA BOT
WANNOFC
RUZTANXD

#MAAF KLO ADA YG KURANG INTINYA YQ ALL

JANGAN DI HAPUS SU HARGAI CREDITS DIKIT
*/

const config = {
  token: '7600345211:AAGhNU9R1QJtdSTn5d7EYkY-gugC6PozgLQ',
  adminId: '1835508209', 
  pp: 'https://files.catbox.moe/ypc1w9.jpg',
urladmin: 'https://t.me/SanXDv',
  pp: 'https://files.catbox.moe/ypc1w9.jpg',
    //SERVER 1
  domain: 'https://kenzovvipserv.abiloffc.biz.id', // Isi dengan domain yang digunakan
  plta: 'ptla_fdvP3VfCsqY9VLVxxP9jdLrn7d7Xq2bMEwGa3jFWPVS', // Isi dengan nilai plta yang sesuai
  pltc: 'ptlc_AlklbAvaEVY3SiXzY97FbTJLjaRyljdkevyvea75Gz8', // Isi dengan nilai pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = config;