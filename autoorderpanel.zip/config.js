/*

  © Created by : Tn Ajie Inc (Developer)
      Thanks yang tidak hapus WM :)
  
  WARNING..!!
- DI LARANG MEMBAGIKAN SC SECARA GRATIS
- DI LARANG MENJUAL DENGAN HARGA 271T

© Copyright 2021 - 2025 Nexus Inc

*/

const config = {
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// UTAMA
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//

  BOT_TOKEN: "7486385374:AAEwNwweDqRjsSwYA0_lkDQWiZCFqQRG5t8",
  OWNER_ID: "5894696119",
  urladmin: "https://t.me/sipicung",
  urlchannel: "https://t.me/picungsociety",
    
 // Duitku Config

  DUITKU_MERCHANT_CODE: "D20182",

  DUITKU_API_KEY: "caa4719cecc7354ad8671daf42a44d82",
  
  apiDigitalOcean: 'dop_v1_7c5a3e8187a1f1ea606615b7f95115fe5a09af1e786cce17526c12ee2b22a11b', // <-- DARI CONFIG LAMA ANDA
  passwordvps: 'VpsTinYoshi', // <-- DARI CONFIG LAMA ANDA
  urlown: "https://t.me/sipicung",
  
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// PTERODACTYL SETTING
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
  
  domain: "https://fanzzz.404-eror.systems",
  plta: "ptla_MlKIQoH4H55YPTjaF9ZDVhAhWX7LsRSHaaJdplxg7o5",
  ptlc: "ptlc_dih3OthphCOtq9jp8DmE1siUIo7Rt18rmw5unR11zZR",
  egg: 15,
  loc: 1,
  
  // Setting loc & egg di file products.js juga
  
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// ATLANTIC SETTING
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
  ApiAtlantic: "CfMXjK0CxMfyeIc3uJnAELWgFUSC9xqo6anX0kIYYDqfB7lIqrKXQeZKjoPz42SYYoGIXg20HPRTdkpMJQyduyqr2PKCP7uZEbA9",
  ApiAtlantic_Key: "CfMXjK0CxMfyeIc3uJnAELWgFUSC9xqo6anX0kIYYDqfB7lIqrKXQeZKjoPz42SYYoGIXg20HPRTdkpMJQyduyqr2PKCP7uZEbA9",
  apiAtlantic: "CfMXjK0CxMfyeIc3uJnAELWgFUSC9xqo6anX0kIYYDqfB7lIqrKXQeZKjoPz42SYYoGIXg20HPRTdkpMJQyduyqr2PKCP7uZEbA9",
  typeewallet: "DANA",
  nopencairan: "081246238773",
  atasnamaewallet: "picung"
  
};
module.exports = config;