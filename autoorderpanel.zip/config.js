/*

  © Created by : Tn Ajie Inc (Developer)
      Thanks yang tidak hapus WM :)
  
  WARNING..!!
- DI LARANG MEMBAGIKAN SC SECARA GRATIS
- DI LARANG MENJUAL DENGAN HARGA 271T

© Copyright 2021 - 2025 Nexus Inc

*/

const config = {
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// UTAMA
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//

  BOT_TOKEN: "7486385374:AAEwNwweDqRjsSwYA0_lkDQWiZCFqQRG5t8",
  OWNER_ID: "5894696119",
  urladmin: "https://t.me/sipicung",
  urlchannel: "https://t.me/picungsociety",
    
 // Duitku Config

  DUITKU_MERCHANT_CODE: "D20182",

  DUITKU_API_KEY: "caa4719cecc7354ad8671daf42a44d82",
  
  apiDigitalOcean: 'dop_v1_7c5a3e8187a1f1ea606615b7f95115fe5a09af1e786cce17526c12ee2b22a11b', // <-- DARI CONFIG LAMA ANDA
  passwordvps: 'VpsTinYoshi', // <-- DARI CONFIG LAMA ANDA
  urlown: "https://t.me/sipicung",
  
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// PTERODACTYL SETTING
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
  
  domain: "https://anti-sus.kibiljoe.engineer",
  plta: "ptla_vGb4XAoylbwKMyjqlX9a3omMsJ1727ZnDoFgXnMu7Qi",
  ptlc: "ptlc_FmAK3c8RX0PKNi5Oif2ZWeH0ZNW60IOG854IhAwFx8t",
  egg: 15,
  loc: 1,
  
  // Setting loc & egg di file products.js juga
  
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// ATLANTIC SETTING
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
  ApiAtlantic: "CfMXjK0CxMfyeIc3uJnAELWgFUSC9xqo6anX0kIYYDqfB7lIqrKXQeZKjoPz42SYYoGIXg20HPRTdkpMJQyduyqr2PKCP7uZEbA9",
  ApiAtlantic_Key: "CfMXjK0CxMfyeIc3uJnAELWgFUSC9xqo6anX0kIYYDqfB7lIqrKXQeZKjoPz42SYYoGIXg20HPRTdkpMJQyduyqr2PKCP7uZEbA9",
  apiAtlantic: "CfMXjK0CxMfyeIc3uJnAELWgFUSC9xqo6anX0kIYYDqfB7lIqrKXQeZKjoPz42SYYoGIXg20HPRTdkpMJQyduyqr2PKCP7uZEbA9",
  typeewallet: "DANA",
  nopencairan: "081246238773",
  atasnamaewallet: "picung"
  
};
module.exports = config;