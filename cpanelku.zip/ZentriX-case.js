    /*
• Base Ori GhostXmods X WannOFFC
Penting ‼
*/

import TelegramBot from 'node-telegram-bot-api';
import axios from 'axios';
import cron from 'node-cron';
import fs from 'fs';
import fetch from 'node-fetch';
import settings from './settings.js';
const botToken = settings.token;
const owner = settings.adminId;
const adminfile = 'adminID.json';
const ownFile = 'ownerID.json';
const premiumUsersFile = 'premiumUsers.json';
const allowedGroupsFile = 'allowedGroups.json';
const autoDeleteSettingsFile = 'autoDeleteSettings.json';
const offlineServersFile = 'offlineServers.json';
let offlineServers = {};
let autoDeleteSettings = { enabled: true };
let allowedGroups = [];
let pendingPayments = {};
let premiumUsers = [];
let adminUsers = [];
const serverStatus = {};
let ownUsers;
const domain = settings.domain;
const plta = settings.plta;
const pltc = settings.pltc;
const picture = settings.picture;
const pteropic = settings.ptero;
const url_bot = settings.url_bot;
const url_ch = settings.url_ch;

try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile, "utf8"));
} catch (error) {
    console.error('Error Membaca File Premium Users:', error);
}
const bot = new TelegramBot(botToken, { polling: true });
try {
    adminUsers = JSON.parse(fs.readFileSync(adminfile, "utf8"));
} catch (error) {
    console.error('Error Membaca File Admin Users:', error);
}
try {
    ownUsers = JSON.parse(fs.readFileSync(ownFile));
} catch (error) {
    console.error('Error Membaca File Owner Users:', error);
    ownUsers = [];
}
try {
    autoDeleteSettings = JSON.parse(fs.readFileSync(autoDeleteSettingsFile, "utf8"));
} catch (error) {
    console.error('Error reading auto-delete settings:', error);
    fs.writeFileSync(autoDeleteSettingsFile, JSON.stringify(autoDeleteSettings));
}
try {
    offlineServers = JSON.parse(fs.readFileSync(offlineServersFile, "utf8"));
} catch (error) {
    console.error('Error membaca file offlineServers:', error);
    offlineServers = {};
}
try {
    allowedGroups = JSON.parse(fs.readFileSync(allowedGroupsFile, "utf8"));
} catch (error) {
    console.error('Error Membaca File Allowed Groups:', error);
    allowedGroups = [];
}

function getRuntime(startTime) {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}
const nama = 'Yoshi';
const author = 'Yoshi';
const version = 'Beta Version';

const startTime = Date.now();


//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//


//=== Greetings From Developer! Original Code From © Yoshi [ Yoshi Developer]

bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username || "User";
    const jerjer = `<b>¡Bonjour, mon ami! @${sender} 👋</b>
    
<b>— 「 Bot Assisten 」</b>
<b>🚀 ${nama}</b> kini hadir untuk mempermudah proses membuat <b>pterodactyl server</b> dengan cepat dan efisien

<b>— 「 Cara Menggunakan 」</b>
🛠️ Cukup dengan <b>perintah yang mudah</b>, yaitu mengetik /help akan memunculkan semua fitur yang tersedia pada bot

<b>🜲 Made With Love</b>`;

    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Channel', url: 't.me/hitsssh' }, { text: 'Owner', url: 't.me/kibiljoe' }]
            ]
        }
    };

    bot.sendPhoto(chatId, settings.picture, {
        caption: jerjer,
        parse_mode: 'HTML',
        reply_markup: keyboard.reply_markup
    });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//


bot.onText(/\/id/, (msg) => {
    const chatId = msg.chat.id;
    const chatType = msg.chat.type;

    // Tentukan target user: user yang direply atau pengirim command
    const targetUser = msg.reply_to_message ? msg.reply_to_message.from : msg.from;

    // Ambil detail dari target user
    const userId = targetUser.id;
    const userFirstName = targetUser.first_name || "Tidak diketahui";
    const userUsername = targetUser.username ? `@${targetUser.username}` : "Tidak ada username";

    // Format pesan untuk Info User
    let userInfoText = `<b>User Info:</b>\n`;
    userInfoText += `<b>ID:</b> <code>${userId}</code>\n`;
    userInfoText += `<b>Nama:</b> ${userFirstName}\n`;
    userInfoText += `<b>Username:</b> ${userUsername}\n`;
    userInfoText += `<b>Link User:</b> <a href="tg://user?id=${userId}">klik ini</a>`;

    // Cek apakah command dijalankan di grup atau supergroup
    if (chatType === 'group' || chatType === 'supergroup') {
        // Ambil detail grup
        const groupId = msg.chat.id;
        const groupTitle = msg.chat.title;

        // Format pesan untuk Info Grup
        let groupInfoText = `<b>Group Info:</b>\n`;
        groupInfoText += `<b>ID Grup:</b> <code>${groupId}</code>\n`;
        groupInfoText += `<b>Nama Grup:</b> ${groupTitle}`;

        // Gabungkan pesan user dan grup
        const finalText = `${userInfoText}\n\n${groupInfoText}`;
        bot.sendMessage(chatId, finalText, { parse_mode: "HTML" });

    } else { // Jika bukan di grup (private chat)
        // Kirim hanya info user
        bot.sendMessage(chatId, userInfoText, { parse_mode: "HTML" });
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//

bot.onText(/\/help/, (msg) => {
  const chatId = msg.chat.id;
  const sender = msg.from.username;
  const texthoho = `<b>¡Hola, amigo! @${sender}</b> 👋
    
<blockquote><b><i>Premium - Admin - Owner Fitur</i></b></blockquote>

<b>—「 Create Panel 」</b>
🛠️ Gunakan fitur ini di grup untuk membuat panel, yaitu /create. Formatnya adalah /create [username],[Id]. Setelah itu bisa mengklik jumlah kapasitas server pada button yang tersedia

<b>—「 Manage Allowed Groups 」</b>
👑 Fitur ini digunakan untuk menambahkan grup ke database whitelist supaya bisa digunakan untuk membuat panel. /allowgroup [ID_Grup] untuk menambahkan dan /removegroup [ID_Grup] untuk menghapus grup dari daftar whitelist

<b>—「 Cek ID User 」</b>
🚀 Gunakan fitur ini untuk mempermudah anda mengetahui ID user. Cara penggunaan adalah /id dan bot akan mengirimkan ID beserta username anda

<b>—「 List User dan Server 」</b>
📚 Gunakan fitur ini untuk melihat list user dan server pada pterodactyl. Untuk menggunakan fitur ini ketik /listsrv atau /listusr. Setelah itu akan muncul list pada server panel anda.

<b>—「 Delete Server dan User 」</b>
💫 Gunakan fitur ini untuk menghapus user atau server dari server pterodactyl anda. Untuk menghapus satu server atau user gunakan /delusr [Id] atau /delsrv [Id], sedangkan untuk <b>membersihkan banyak server</b> /clearusr [Excluded-Id] atau /clearsrv [Excluded-Id].

"<b>—「 Tambah Server ke User Yang Sudah Ada 」</b>
🔧 Gunakan /serverin [ID_User] [Nama_Server] untuk menambahkan server ke user yang sudah ada (Maks 2 server per user)"

<b>—「 Toggle Auto Delete Server 」</b>
🧊 Gunakan fitur ini untuk mengaktifkan / menonaktifkan fitur auto delete. Gunakan /autodelete on atau /autodelete off

<b>—「 Fitur Add to Databse 」</b>
💎 Gunakan fitur ini untuk menambahkan user ke database premium, admin, dan owner. Untuk menggunakan fitur ini, ketik /addprem [Id], /addadmin [Id], atau addowner [Id]
`;

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Channel', url: 'https://t.me/hitsssh' }, { text: 'Owner', url: 'https://t.me/kibiljoe' }]
      ]
    }
  };

  bot.sendMessage(chatId, texthoho, {
    parse_mode: 'HTML',
    reply_markup: keyboard.reply_markup
  });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addprem
bot.onText(/\/addprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Channel', url: 'https://t.me/hitsssh' }, { text: 'Owner', url: 'https://t.me/kibiljoe' }]
      ]
    }
  };
    const senderId = msg.from.id.toString(); // Ubah ke string agar konsisten

    // Pastikan senderId ada di daftar owner atau admin
    if (ownUsers.includes(senderId) || adminUsers.includes(senderId)) {
        if (!premiumUsers.includes(userId)) {
            premiumUsers.push(userId);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `✅ User ${userId} berhasil ditambahkan ke database premium.`, {parse_mode: 'HTML', reply_markup: keyboard.reply_markup
  });
        } else {
            bot.sendMessage(chatId, `⚠️ User ${userId} sudah terdaftar dalam database premium.`, {parse_mode: 'HTML', reply_markup: keyboard.reply_markup
  });
        }
    } else {
        bot.sendMessage(chatId, '⛔ Anda <b>tidak memiliki izin</b> untuk menggunakan perintah ini.', {parse_mode: 'HTML', reply_markup: keyboard.reply_markup
  });
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/delprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Channel', url: 'https://t.me/hitsssh' }, { text: 'Owner', url: 'https://t.me/kibiljoe' }]
      ]
    }
  };
    const senderId = msg.from.id.toString();
    if (ownUsers.includes(senderId) || adminUsers.includes(senderId)) {
        const index = premiumUsers.indexOf(userId);
        if (index !== -1) {
            premiumUsers.splice(index, 1);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `✅ User ${userId} berhasil dihapus dari database premium.`);
        } else {
            bot.sendMessage(chatId, `⚠️ User ${userId} tidak ditemukan dalam database premium.`);
        }
    } else {
        bot.sendMessage(chatId, '⛔ Anda tidak memiliki izin untuk menggunakan perintah ini.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addowner
bot.onText(/\/addowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!adminUsers.includes(userId)) {
            adminUsers.push(userId);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to admin users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already an admin user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});

// delowner
bot.onText(/\/delowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        const index = adminUsers.indexOf(userId);
        if (index !== -1) {
            adminUsers.splice(index, 1);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from admin users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not an admin user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//delusr
bot.onText(/\/delusr(.*)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const usr = match[1].trim();
      
      const adminUsers = JSON.parse(fs.readFileSync(adminfile, "utf8"));
      const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah hanya untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Hubungi Admin', url: 'https://t.me/kibiljoe' }
                    ]
                ]
            }
        });
        return;
    }

    if (!usr) {
        bot.sendMessage(chatId, 'Mohon masukkan ID server yang ingin dihapus, contoh: /delusr 1234');
        return;
    }

    try {
        let f = await fetch(`${domain}/api/application/users/${usr}`, {
	            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });

        let res = f.ok ? { errors: null } : await f.json();

        if (res.errors) {
            bot.sendMessage(chatId, 'User Tidak Ditemukan');
        } else {
            bot.sendMessage(chatId, 'Berhasil Menghapus Database User');
        }
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan saat menghapus server.');
    }
});
//==============
bot.onText(/\/addadmin (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    const sate = {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Channel', url: 't.me/kibiljoe' }, { text: 'Owner', url: 't.me/kibiljoe' }]
      ]
    }
  };
    const senderId = msg.from.id.toString(); // Ubah ke string agar konsisten

    // Pastikan senderId ada di daftar owner atau admin
    if (ownUsers.includes(senderId)) {
        if (!adminUsers.includes(userId)) {
            adminUsers.push(userId);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `✅ User ${userId} <b>berhasil ditambahkan</b> ke database admin.`, {parse_mode: 'HTML', reply_markup: sate.reply_markup
  });
        } else {
            bot.sendMessage(chatId, `⚠️ User ${userId} <b>sudah terdaftar dalam database</b> premium.`, {parse_mode: 'HTML', reply_markup: sate.reply_markup
  });
        }
    } else {
        bot.sendMessage(chatId, '⛔ Anda <b>tidak memiliki izin</b> untuk menggunakan perintah ini.', {parse_mode: 'HTML', reply_markup: sate.reply_markup
  });
    }
});

bot.onText(/^(\.|\#|\/)create$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `Format salah!\nPenggunaan: /create [username],[id]`);
  });
bot.onText(/\/create (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    
    if (msg.chat.type === 'private' || !allowedGroups.includes(chatId.toString())) {
        return bot.sendMessage(chatId, '⛔ Perintah ini hanya dapat digunakan di grup yang diizinkan!');
    }
    
    const text = match[1];
    let premiumUsers = [];
  try {
      premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile, "utf8"));
  } catch (error) {
      console.error('Error Membaca File Premium:', error);
      fs.writeFileSync(premiumUsersFile, "[]"); // Buat file kosong
  }
    const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
    const noakses = `💎 Anda Tidak Terdaftar Pada <b>Database Premium Users</b>. Silahkan Hubungi Owner`;

    const keyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Channel', url: 'https://t.me/hitsssh' }, { text: 'Owner', url: 'https://t.me/kibiljoe' }]
        ]
      }
    };

    bot.sendMessage(chatId, noakses, { 
      parse_mode: 'HTML', 
      reply_markup: keyboard.reply_markup 
    });

    return;
  }

  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Format salah!\nPenggunaan: /create [username],[id]');
    return;
  }

  const username = t[0];
  const userId = t[1];

  bot.sendMessage(chatId, 'Pilih Jumlah Kapasitasnya Panel yang Anda Inginkan:', {
    reply_markup: {
      inline_keyboard: [
        [{ text: '1GB', callback_data: `createpanel_${username}_${userId}_1` }, { text: '2GB', callback_data: `createpanel_${username}_${userId}_2` }],
        [{ text: '3GB', callback_data: `createpanel_${username}_${userId}_3` }, { text: '4GB', callback_data: `createpanel_${username}_${userId}_4` }],
        [{ text: '5GB', callback_data: `createpanel_${username}_${userId}_5` }, { text: '6GB', callback_data: `createpanel_${username}_${userId}_6` }],
        [{ text: '7GB', callback_data: `createpanel_${username}_${userId}_7` }, { text: '8GB', callback_data: `createpanel_${username}_${userId}_8` }],
        [{ text: '9GB', callback_data: `createpanel_${username}_${userId}_9` }, { text: 'Unlimited', callback_data: `createpanel_${username}_${userId}_Unlimited` }]
      ]
    }
  }).then((sentMessage) => {
    bot.panelSelectionMessageId = sentMessage.message_id;
  });
});

// createadmin
bot.onText(/\/createadmin (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));
  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "BAYAR TOLOL GRATISAN MULU",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "HUBUNGI ADMIN", url: "https://t.me/kibiljoe" }],
          ],
        },
      }
    );
    return;
  }
  const commandParams = match[1].split(",");
  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();
  if (commandParams.length < 2) {
    bot.sendMessage(
      chatId,
      "Format Salah! Penggunaan: /createadmin [username],[idtele]"
    );
    return;
  }
  const password = panelName + "117";
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: `${panelName}@admin.Xhin`,
        username: panelName,
        first_name: panelName,
        last_name: "Memb",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: user
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
    `;
    bot.sendMessage(chatId, userInfo);
    bot.sendMessage(
      telegramId,
      `
┏━⬣❏「 INFO DATA ADMIN PANEL 」❏
│➥  Login : ${domain}
│➥  Username : ${user.username}
│➥  Password : ${password} 
┗━━━━━━━━━⬣
│ Rules : 
│• Jangan Curi Sc
│• Jangan Buka Panel Orang
│• Jangan Ddos Server
│• Kalo jualan sensor domainnya
│• Jangan Bagi² Panel Free !!
│• Jangan bagi bagi panel free !! ngelanggar? maklu matyy
┗━━━━━━━━━━━━━━━━━━⬣
THANKS FOR BUYING
    `
    );
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
fs.readFile(adminfile, (err, data) => {
  if (err) {
    console.error(err);
  } else {
    let adminIDs = JSON.parse(data);
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//

bot.onText(/\/allowgroup (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const groupId = match[1].trim(); // Ambil ID grup dan hilangkan spasi
    const senderId = msg.from.id.toString();

    if (adminUsers.includes(senderId) || ownUsers.includes(senderId)) {
        const groupIdStr = groupId.toString();
        
        if (!allowedGroups.includes(groupIdStr)) {
            allowedGroups.push(groupIdStr);
            fs.writeFileSync(allowedGroupsFile, JSON.stringify(allowedGroups));
            bot.sendMessage(chatId, `✅ Grup ${groupIdStr} berhasil ditambahkan ke whitelist!`);
        } else {
            bot.sendMessage(chatId, `⚠️ Grup ${groupIdStr} sudah ada dalam whitelist!`);
        }
    } else {
        bot.sendMessage(chatId, '⛔ Hanya Admin/Owner yang bisa menggunakan perintah ini!');
    }
});

bot.onText(/\/removegroup (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const groupId = match[1].trim();
    const senderId = msg.from.id.toString();

    if (adminUsers.includes(senderId) || ownUsers.includes(senderId)) {
        const groupIdStr = groupId.toString();
        const index = allowedGroups.indexOf(groupIdStr);
        
        if (index !== -1) {
            allowedGroups.splice(index, 1);
            fs.writeFileSync(allowedGroupsFile, JSON.stringify(allowedGroups));
            bot.sendMessage(chatId, `✅ Grup ${groupIdStr} berhasil dihapus dari whitelist!`);
        } else {
            bot.sendMessage(chatId, `⚠️ Grup ${groupIdStr} tidak ditemukan dalam whitelist!`);
        }
    } else {
        bot.sendMessage(chatId, '⛔ Hanya Admin/Owner yang bisa menggunakan perintah ini!');
    }
});

bot.on('callback_query', async (callbackQuery) => {
  const msg = callbackQuery.message;
  const data = callbackQuery.data.split('_');

  if (data[0] === 'createpanel') {
    let username = data[1];
    username = username.charAt(0).toUpperCase() + username.slice(1).toLowerCase();
    const userId = data[2];
    const size = data[3];

    let memory, disk, cpu;
    if (size === 'Unlimited') {
      memory = '0';
      disk = '0';
      cpu = '0';
    } else {
      memory = `${parseInt(size) * 1024}`;
      disk = `${parseInt(size) * 1024}`;
      cpu = `${parseInt(size) * 75}`;
    }

    const name = `${username} Server`;
    const email = `${username}@gmail.com`;

    const generatePassword = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let password = '';
  for (let i = 0; i < 6; i++) {
    password += chars[Math.floor(Math.random() * chars.length)];
  }
  return password;
};

    const password = generatePassword();

    try {
      if (bot.panelSelectionMessageId) {
        bot.deleteMessage(msg.chat.id, bot.panelSelectionMessageId).catch(console.error);
      }

      // Membuat user
      const userResponse = await fetch(`${settings.domain}/api/application/users`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${settings.plta}`
        },
        body: JSON.stringify({
          email: email,
          username: username,
          first_name: username,
          last_name: username,
          language: 'en',
          password: password
        })
      });

      const userData = await userResponse.json();
      if (userData.errors) {
        bot.sendMessage(msg.chat.id, `Error: ${JSON.stringify(userData.errors[0], null, 2)}`);
        return;
      }

      const user = userData.attributes;

      // Membuat server
      const serverResponse = await fetch(`${settings.domain}/api/application/servers`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${settings.plta}`
        },
        body: JSON.stringify({
          name: name,
          description: '',
          user: user.id,
          egg: parseInt(settings.eggs),
          docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
          startup: 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}',
          environment: {
            INST: 'npm',
            USER_UPLOAD: '0',
            AUTO_UPDATE: '0',
            CMD_RUN: 'npm start'
          },
          limits: {
            memory: memory,
            swap: 0,
            disk: disk,
            io: 500,
            cpu: cpu
          },
          feature_limits: {
            databases: 5,
            backups: 5,
            allocations: 1
          },
          deploy: {
            locations: [parseInt(settings.loc)],
            dedicated_ip: false,
            port_range: []
          }
        })
      });

      const serverData = await serverResponse.json();
      const server = serverData.attributes;

      bot.sendMessage(msg.chat.id, `Server Panel ${size} GB Berhasil Dibuat`);

                        
          const Text100= `<b>Ciao, amico! This is your order ✨</b>

<blockquote><b><i>Berikut adalah Data Panel Anda</i></b></blockquote>
» Domain : ${domain}
» Username : <code>${user.username}</code>
» Password : <code>${password}</code>

<blockquote><b><i>Catatan Penting</i></b></blockquote>
• Jangan Share Domain atau Data Panel
• Simpan Data Dengan Baik
• Jangan Biarkan Server Off Selama 24 Jam
• Jangan Digunakan untuk Run Tools DDoS
• Claim Garansi Maks 15 Hari (2x Replace)

<b>🜲 Made With Love</b>`
const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Domain', url: `${settings.domain}` }, { text: 'Owner', url: 't.me/kibiljoe' }]
            ]
        }
    }
      bot.sendPhoto(userId, pteropic, {
      caption: Text100,
      parse_mode: 'HTML',
      reply_markup: keyboard.reply_markup
       
         });

      bot.sendMessage(msg.chat.id, `💎 Data Panel Telah Dikirimkan Kepada ID Tujuan`);
    } catch (error) {
      bot.sendMessage(msg.chat.id, `Error: ${error.message}`);
    }
  }
});

bot.onText(/\/listsrv/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));   
    
    if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'HUBUNGI ADMIN', url: 'https://t.me/kibiljoe' }
                    ]
                ]
            }
        });
        return;
    }

    try {
        // Ambil daftar server dari API Application
        let serverRes = await fetch(`${domain}/api/application/servers`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        
        let serverData = await serverRes.json();
        let servers = serverData.data;
        
        let messageText = "Daftar server aktif yang dimiliki:\n\n";
        
        for (let server of servers) {
            const s = server.attributes;
            let runtimeStatus = "🔴 Mati";
            
            try {
                // Gunakan endpoint Client API dengan pltc token
                const utilRes = await fetch(
                    `${domain}/api/client/servers/${s.identifier}/resources`,
                    {
                        headers: { 
                            'Authorization': `Bearer ${pltc}`,
                            'Accept': 'application/json' 
                        }
                    }
                );
                
                if (utilRes.ok) {
                    const utilData = await utilRes.json();
                    runtimeStatus = (utilData.attributes.current_state === "running" || utilData.attributes.current_state === "starting") 
                        ? "🟢 Aktif" 
                        : "🔴 Mati";
                }
            } catch (error) {
                console.error("Gagal ambil status:", error);
            }

            messageText += `🆔 ID: ${s.id}\n`;
            messageText += `📛 Nama: ${s.name}\n`;
            messageText += `📊 Status: ${runtimeStatus}\n\n`;
        }

        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});

bot.onText(/\/delsrv(.*)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const srv = match[1].trim();

    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah hanya untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Hubungi Admin', url: 'https://t.me/kibiljoe' }
                    ]
                ]
            }
        });
        return;
    }

    if (!srv) {
        bot.sendMessage(chatId, 'Mohon masukkan ID server yang ingin dihapus, contoh: /delsrv 1234');
        return;
    }

    try {
        let f = await fetch(`${domain}/api/application/servers/${srv}`, {
            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });

        let res = f.ok ? { errors: null } : await f.json();

        if (res.errors) {
            bot.sendMessage(chatId, 'SERVER NOT FOUND');
        } else {
            bot.sendMessage(chatId, 'SUCCESSFULLY DELETE THE SERVER');
        }
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan saat menghapus server.');
    }
});

// listusr
bot.onText(/\/listusr/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    // Cek status admin dan premium
    const isAdmin = adminUsers.includes(String(userId));
    const isPremium = premiumUsers.includes(String(userId));

    if (!isAdmin && !isPremium) {
        bot.sendMessage(chatId, '⛔ Perintah ini hanya untuk Admin/Premium User!', {
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'Upgrade Premium', url: 'https://t.me/kibiljoe' }]
                ]
            }
        });
        return;
    }

    let page = '1';
    try {
        let f = await fetch(`${domain}/api/application/users?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let users = res.data;
        let messageText = "Berikut List User Panel :\n\n";
        for (let user of users) {
            let u = user.attributes;   
                messageText += `🆔 ID User: ${u.id}\n`;
                messageText += `📛 Username: ${u.username}\n`;
                messageText += `📣 Nama: ${u.first_name} ${u.last_name}\n\n`;
            }
            
        messageText += `Page : ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `Total User : ${res.meta.pagination.count}`;
        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});

// listadmin
bot.onText(/\/listadmin/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));
    if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'HUBUNGI ADMIN', url: 'https://t.me/kibiljoe' }
                    ]
                ]
            }
        });
        return;
    }
    let page = '1';
    try {
        let f = await fetch(`${domain}/api/application/users?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let users = res.data;
        let messageText = "Berikut list admin :\n\n";
        for (let user of users) {
            let u = user.attributes;
            if (u.root_admin) {
                messageText += `🆔 ID: ${u.id} - 🌟 Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
                messageText += `${u.username}\n`;
                messageText += `${u.first_name} ${u.last_name}\n\n`;
                messageText += 'By ./VanzOffc';
            }
        }
        messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `Total Admin: ${res.meta.pagination.count}`;
        const keyboard = [
            [
                { text: 'BACK', callback_data: JSON.stringify({ action: 'back', page: parseInt(res.meta.pagination.current_page) - 1 }) },
                { text: 'NEXT', callback_data: JSON.stringify({ action: 'next', page: parseInt(res.meta.pagination.current_page) + 1 }) }
            ]
        ];
        bot.sendMessage(chatId, messageText, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});

//=========================================
bot.onText(/\/clearusr(.*)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const excludedUsers = match[1] ? match[1].trim().split(' ') : [];

    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, '- *Akses Ditolak*\nFitur Khusus Owner');
        return;
    }

    try {
        let response = await fetch(`${domain}/api/application/users`, {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": `Bearer ${settings.plta}`,
            }
        });

        let users = await response.json();
        if (!users || users.errors) {
            bot.sendMessage(chatId, 'Gagal mengambil daftar user!');
            return;
        }

        let usersToDelete = users.data.filter(user => !excludedUsers.includes(user.attributes.id.toString()));

        if (usersToDelete.length === 0) {
            bot.sendMessage(chatId, 'Tidak ada user untuk dihapus!');
            return;
        }

        for (let user of usersToDelete) {
            let deleteResponse = await fetch(`${domain}/api/application/users/${user.attributes.id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${settings.plta}`,
                }
            });

            if (deleteResponse.ok) {
                bot.sendMessage(chatId, `Sukses menghapus user ${user.attributes.id}`);
            } else {
                bot.sendMessage(chatId, `Gagal menghapus user ${user.attributes.id}`);
            }
        }

        bot.sendMessage(chatId, 'Proses penghapusan user selesai!');
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan saat menghapus user.');
    }
});

bot.onText(/\/clearsrv(.*)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const excludedServers = match[1] ? match[1].trim().split(' ') : [];

    try {
        if (!fs.existsSync(adminfile)) {
            bot.sendMessage(chatId, '❗ File admin tidak ditemukan!');
            return;
        }

        // Membaca daftar admin dan memeriksa formatnya
        const adminUsers = JSON.parse(fs.readFileSync(adminfile, 'utf8'));
        if (!Array.isArray(adminUsers)) {
            bot.sendMessage(chatId, '❗ Format file admin tidak valid!');
            return;
        }

        // Cek apakah pengguna adalah admin
        if (!adminUsers.includes(String(msg.from.id))) {
            bot.sendMessage(chatId, '- *Akses Ditolak*\nFitur Khusus Owner');
            return;
        }

        // Ambil daftar server dari API
        let serversData;
        try {
            const response = await fetch(`${settings.domain}/api/application/servers`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${settings.plta}`
                }
            });

            if (!response.ok) {
                bot.sendMessage(chatId, `❗ Gagal mengambil daftar server! Kode Status: ${response.status}`);
                return;
            }

            serversData = await response.json();
        } catch (error) {
            console.error('Error saat mengambil daftar server:', error);
            bot.sendMessage(chatId, '❗ Terjadi kesalahan saat mengambil daftar server.');
            return;
        }

        // Pastikan data server valid
        if (!serversData || !serversData.data || !Array.isArray(serversData.data)) {
            bot.sendMessage(chatId, '❗ Data server tidak valid atau kosong!');
            return;
        }

        // Filter server yang akan dihapus (semua kecuali yang ada di excludedServers)
        let serversToDelete = serversData.data.filter(server => 
            !excludedServers.includes(server.attributes.id.toString()) // Cek apakah ID server ada dalam daftar pengecualian
        );

        if (serversToDelete.length === 0) {
            bot.sendMessage(chatId, '✅ Tidak ada server untuk dihapus!');
            return;
        }

        // Hapus server satu per satu
        for (let server of serversToDelete) {
            try {
                const deleteResponse = await fetch(`${settings.domain}/api/application/servers/${server.attributes.id}`, {
                    method: "DELETE",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${settings.plta}`
                    }
                });

                if (deleteResponse.ok) {
                    bot.sendMessage(chatId, `✅ Sukses menghapus server ${server.attributes.id}`);
                } else {
                    const errorText = await deleteResponse.text();
                    bot.sendMessage(chatId, `❌ Gagal menghapus server ${server.attributes.id}: ${errorText}`);
                }
            } catch (error) {
                console.error(`Error saat menghapus server ${server.attributes.id}:`, error);
                bot.sendMessage(chatId, `❗ Terjadi kesalahan saat menghapus server ${server.attributes.id}`);
            }
        }

        bot.sendMessage(chatId, '🚀 Proses penghapusan server selesai!');
    } catch (error) {
        console.error('Error utama:', error);
        bot.sendMessage(chatId, '❗ Terjadi kesalahan tak terduga.');
    }
});


//==================================
// Membaca file PremiumUsers.json (jika ada)

// Fungsi untuk menambahkan pengguna premium ke dalam file JSON
function addPremiumUser(userId) {
    let premiumUsers = [];

    if (fs.existsSync(premiumUsersFile)) {
        try {
            premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile, "utf8"));
        } catch (error) {
            console.error("Gagal membaca file premium:", error);
            return;
        }
    }

    if (!premiumUsers[userId]) {
        premiumUsers[userId] = {
            expired: Date.now() + 30 * 24 * 60 * 60 * 1000 // Masa aktif 30 hari
        };

        try {
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers, null, 2));
            console.log(`User ${userId} berhasil ditambahkan ke Premium.`);
        } catch (error) {
            console.error("Gagal menyimpan file JSON:", error);
        }
    }
}

// Fungsi bantuan: sleep (delay)
function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

// Fungsi bantuan: format angka
function toIDR(amount) {
    return amount.toString();
}

bot.onText(/\/buyprem/, async (msg) => {
    const chatId = msg.chat.id;
    if (msg.chat.type !== "private") return bot.sendMessage(chatId, `⚠️ Gunakan di Private Chat!`);

    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile, "utf8")) || {};
    if (premiumUsers[chatId]) return bot.sendMessage(chatId, "✅ Anda sudah memiliki akses premium!");

    if (pendingPayments[chatId]) return bot.sendMessage(chatId, "❌ Anda memiliki transaksi pending! (/batalprem untuk membatalkan)");

    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: "💳 Bayar Sekarang", callback_data: "buyprem_confirm" }],
                [{ text: "❌ Batal", callback_data: "buyprem_cancel" }]
            ]
        }
    };
    bot.sendMessage(chatId, "🛒 Beli Akses Premium (Rp10.000)\n\nDurasi: 30 Hari\nFitur Eksklusif:\n- Create Panel Unlimited\n- Prioritas Support", keyboard);
});

bot.on("callback_query", async (callbackQuery) => {
    const data = callbackQuery.data;
    const chatId = callbackQuery.message.chat.id;
    const apiKey = "simplebotz85";

    if (data === "buyprem_cancel") {
        if (pendingPayments[chatId]) {
            clearTimeout(pendingPayments[chatId].timer);
            delete pendingPayments[chatId];
        }
        bot.deleteMessage(chatId, callbackQuery.message.message_id);
        bot.sendMessage(chatId, "🚫 Transaksi dibatalkan");
        return;
    }

    if (data === "buyprem_confirm") {
        try {
            bot.answerCallbackQuery(callbackQuery.id, { text: "🔍 Membuat transaksi..." });
            
            const amount = 10000;
            const response = await axios.get(`https://api.simplebot.my.id/api/orkut/createpayment?apikey=${apiKey}&amount=${amount}`);
            
            if (!response.data.status || response.data.status !== "success") {
                throw new Error("Gagal membuat QRIS");
            }

            const paymentData = response.data.result;
            pendingPayments[chatId] = {
                transactionId: paymentData.transactionId,
                timer: setTimeout(() => {
                    delete pendingPayments[chatId];
                    bot.sendMessage(chatId, "⌛ QRIS telah kadaluarsa!");
                }, 300000)
            };

            const qrCaption = `🔖 Detail Pembayaran\n\n➤ ID Transaksi: \`${paymentData.transactionId}\`\n➤ Jumlah: *Rp${amount}*\n➤ Batas Waktu: 5 Menit\n\n📸 Scan QRIS dengan aplikasi e-wallet Anda`;
            
            await bot.sendPhoto(chatId, paymentData.qrImageUrl, { 
                caption: qrCaption,
                parse_mode: "Markdown",
                reply_markup: { inline_keyboard: [[{ text: "🔄 Cek Status", callback_data: "check_payment" }]] }
            });

            const checkPayment = async () => {
                for (let i = 0; i < 30; i++) {
                    await new Promise(resolve => setTimeout(resolve, 10000));
                    if (!pendingPayments[chatId]) break;
                    
                    try {
                        const statusRes = await axios.get(`https://api.simplebot.my.id/api/orkut/cekstatus?apikey=${apiKey}&transaction_id=${paymentData.transactionId}`);
                        
                        if (statusRes.data.status === "paid") {
                            clearTimeout(pendingPayments[chatId].timer);
                            delete pendingPayments[chatId];
                            addPremiumUser(chatId);
                            bot.sendMessage(chatId, "🎉 *Pembayaran Berhasil!*\nAkses premium Anda aktif hingga 30 hari ke depan!", { parse_mode: "Markdown" });
                            break;
                        }
                    } catch (error) {
                        console.error("Error cek status:", error);
                    }
                }
            };
            checkPayment();

        } catch (error) {
            console.error("Payment error:", error);
            bot.sendMessage(chatId, `❌ Gagal memproses: ${error.message || "Server payment sedang gangguan"}`);
        }
    }
});

// Command untuk membatalkan pembelian premium
bot.onText(/\/batalprem/, (msg) => {
    const chatId = msg.chat.id;
    if (pendingPayments[chatId]) {
        clearTimeout(pendingPayments[chatId].timer);
        delete pendingPayments[chatId];
        return bot.sendMessage(chatId, "Transaksi telah dibatalkan.");
    }
    bot.sendMessage(chatId, "Tidak ada transaksi yang perlu dibatalkan.");
});

bot.onText(/\/autodelete (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const action = match[1].toLowerCase();
    const senderId = msg.from.id.toString();

    if (!adminUsers.includes(senderId) && !ownUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "⛔ Hanya admin yang bisa mengontrol fitur ini!");
    }

    if (action === 'on' || action === 'off') {
        autoDeleteSettings.enabled = (action === 'on');
        fs.writeFileSync(autoDeleteSettingsFile, JSON.stringify(autoDeleteSettings));
        bot.sendMessage(chatId, `✅ Auto-delete ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
    } else {
        bot.sendMessage(chatId, "❌ Gunakan /autodelete on atau /autodelete off");
    }
});

import os from 'os';
import { performance } from 'perf_hooks';

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function cpuAverage() {
    let totalIdle = 0, totalTick = 0;
    let cpus = os.cpus();

    cpus.forEach((cpu) => {
        for (let type in cpu.times) {
            totalTick += cpu.times[type];
        }
        totalIdle += cpu.times.idle;
    });

    return { idle: totalIdle / cpus.length, total: totalTick / cpus.length };
}

function runtime(seconds) {
    let days = Math.floor(seconds / (3600 * 24));
    let hours = Math.floor((seconds % (3600 * 24)) / 3600);
    let minutes = Math.floor((seconds % 3600) / 60);
    let secs = Math.floor(seconds % 60);
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
}

bot.onText(/\/ping/, async (msg) => {
    const chatId = msg.chat.id;
    let startTime = performance.now();

    let totalMem = formatBytes(os.totalmem());
    let freeMem = formatBytes(os.freemem());

    getCPUUsage(async (cpuUsage) => {
        let response = `
*🔴 SERVER INFORMATION*
• Platform : ${os.type()}
• Total RAM : ${totalMem}
• Free RAM : ${freeMem}
• Total CPU : ${os.cpus().length} Core
• CPU Usage : ${cpuUsage}
• VPS Uptime : ${runtime(os.uptime())}

*🔵 BOT INFORMATION*
• Response Speed : Calculating...
• Bot Uptime : ${runtime(process.uptime())}
        `;

        let sentMessage = await bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });

        let endTime = performance.now();
        let latency = Math.round(endTime - startTime);

        let updatedResponse = response.replace('Calculating...', `${latency} ms`);
        bot.editMessageText(updatedResponse, { chat_id: chatId, message_id: sentMessage.message_id, parse_mode: 'Markdown' });
    });
});

bot.onText(/\/serverin (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const args = match[1].split(' ');
    const userId = msg.from.id.toString();

    // Cek jika digunakan di grup yang diizinkan
    if (msg.chat.type === 'private' || !allowedGroups.includes(chatId.toString())) {
        return bot.sendMessage(chatId, '⛔ Perintah ini hanya dapat digunakan di grup yang diizinkan!');
    }

    // Cek hak akses: Admin, Owner, atau Premium
    const isAdmin = adminUsers.includes(userId);
    const isOwner = ownUsers.includes(userId);
    const isPremium = premiumUsers.includes(userId);

    if (!isAdmin && !isOwner && !isPremium) {
        return bot.sendMessage(chatId, '⛔ Anda tidak memiliki izin untuk menggunakan perintah ini!', {
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'Hubungi Admin', url: 'https://t.me/kibiljoe' }]
                ]
            }
        });
    }

    if (args.length < 2) {
        return bot.sendMessage(chatId, 'Format salah!\nGunakan Format: /serverin iduser namaserver');
    }

    const [targetUserId, ...serverNameParts] = args;
    const rawServerName = serverNameParts.join(' ');
    
    // Format kapitalisasi untuk nama server
    const formattedServerName = rawServerName
        .toLowerCase()
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');

    try {
        // Cek apakah user ada di panel
        const userRes = await fetch(`${domain}/api/application/users/${targetUserId}`, {
            headers: {
                'Authorization': `Bearer ${plta}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (!userRes.ok) {
            return bot.sendMessage(chatId, '❌ User tidak ditemukan!');
        }

        // Cek jumlah server yang dimiliki user
        const allServersRes = await fetch(`${domain}/api/application/servers`, {
            headers: {
                'Authorization': `Bearer ${plta}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (!allServersRes.ok) {
            return bot.sendMessage(chatId, '❌ Gagal mengambil data server!');
        }

        const allServersData = await allServersRes.json();
        const userServers = allServersData.data.filter(server => 
            server.attributes.user.toString() === targetUserId.toString()
        );

        if (userServers.length >= 2) {
            const serverList = userServers.map(server => 
                `▸ ${server.attributes.name} (ID: ${server.attributes.id})`
            ).join('\n');
            
            return bot.sendMessage(chatId,
                `❌ User sudah memiliki ${userServers.length} server! Maksimal 2 server per user.\n` +
                `Daftar Server:\n${serverList}`
            );
        }

        // Proses pembuatan server dengan nama yang diformat
        const serverResponse = await fetch(`${domain}/api/application/servers`, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            },
            body: JSON.stringify({
                name: `${formattedServerName} Server`,
                user: targetUserId,
                egg: parseInt(settings.eggs),
                docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
                startup: 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}',
                environment: {
                    INST: 'npm',
                    USER_UPLOAD: '0',
                    AUTO_UPDATE: '0',
                    CMD_RUN: 'npm start'
                },
                limits: {
                    memory: 0,
                    swap: 0,
                    disk: 0,
                    io: 500,
                    cpu: 0
                },
                feature_limits: {
                    databases: 5,
                    backups: 5,
                    allocations: 1
                },
                deploy: {
                    locations: [parseInt(settings.loc)],
                    dedicated_ip: false,
                    port_range: []
                }
            })
        });

        const serverData = await serverResponse.json();
        if (serverData.errors) {
            return bot.sendMessage(chatId, `❌ Gagal membuat server: ${serverData.errors[0].detail}`);
        }

        bot.sendMessage(chatId, `✅ Server "${formattedServerName} Server" berhasil dibuat untuk user ID ${targetUserId}!`);

    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, '❌ Terjadi kesalahan saat memproses permintaan!');
    }
});

function getCPUUsage(callback) {
    let startMeasure = cpuAverage();

    setTimeout(() => {
        let endMeasure = cpuAverage();
        let idleDifference = endMeasure.idle - startMeasure.idle;
        let totalDifference = endMeasure.total - startMeasure.total;
        let percentageCPU = 100 - (100 * idleDifference / totalDifference);

        callback(percentageCPU.toFixed(2) + "%");
    }, 1000);
}

setInterval(async () => {
    try {
        // Ambil penggunaan CPU sistem
        const cpuUsage = await getSystemCpuUsage();
        
        if (cpuUsage > 70) {
            // Ambil data server dari API admin
            const serversRes = await fetch(`${domain}/api/application/servers`, {
                headers: { 'Authorization': `Bearer ${plta}` }
            });
            const serversData = await serversRes.json();
            
            let problemServers = [];
            
            // Cek setiap server
            for (const server of serversData.data) {
                try {
                    const utilRes = await fetch(
                        `${domain}/api/application/servers/${server.attributes.id}/utilization`, 
                        { headers: { 'Authorization': `Bearer ${plta}` } }
                    );
                    
                    if (utilRes.ok) {
                        const utilData = await utilRes.json();
                        const serverCpu = utilData.attributes.resources.cpu_absolute || 0;
                        
                        if (serverCpu > 70 && utilData.attributes.current_state === 'running') {
                            problemServers.push({
                                id: server.attributes.id,
                                name: server.attributes.name,
                                cpu: serverCpu.toFixed(1)
                            });
                        }
                    }
                } catch (serverError) {
                    console.error(`Error cek server ${server.attributes.id}:`, serverError);
                }
            }
            
            // Kirim notifikasi ke admin
            if (problemServers.length > 0) {
                let alertMessage = `🚨 *CPU WARNING!*\n\n`;
                alertMessage += `🖥️ *System CPU Usage:* ${cpuUsage}%\n`;
                alertMessage += `🔍 *Problem Servers:*\n`;
                
                problemServers.forEach(server => {
                    alertMessage += `▸ ${server.name} (ID: ${server.id}) - ${server.cpu}% CPU\n`;
                });
                
                adminUsers.forEach(adminId => {
                    bot.sendMessage(adminId, alertMessage, {
                        parse_mode: "Markdown",
                        reply_markup: {
                            inline_keyboard: [[
                                { text: "🛠️ Kelola Server", url: `${domain}/admin/servers` }
                            ]]
                        }
                    });
                });
            }
        }
    } catch (mainError) {
        console.error('CPU Monitoring Error:', mainError);
    }
}, 60000); // Cek setiap 1 mnt

async function checkAndDeleteServers() {
    console.log('[CRON] Memulai pengecekan server...');
    if (!autoDeleteSettings.enabled) {
        console.log('[CRON] Auto-delete dinonaktifkan.');
        return;
    }

    try {
        const serverListRes = await fetch(`${settings.domain}/api/application/servers`, {
            headers: { 'Authorization': `Bearer ${settings.plta}` }
        });
        if (!serverListRes.ok) {
            console.error('[ERROR] Gagal mengambil daftar server:', serverListRes.statusText);
            return;
        }

        const serverList = await serverListRes.json();
        console.log(`[DEBUG] Jumlah server: ${serverList.data.length}`);

        for (const server of serverList.data) {
            const serverId = server.attributes.id;
            const serverIdentifier = server.attributes.identifier;
            const isSuspended = server.attributes.suspended;

            try {
                const utilRes = await fetch(
                    `${settings.domain}/api/client/servers/${serverIdentifier}/resources`,
                    {
                        headers: { 
                            'Authorization': `Bearer ${settings.pltc}`,
                            'Accept': 'application/json' 
                        }
                    }
                );

                if (!utilRes.ok) {
                    console.error(`[ERROR] Gagal cek server ${serverIdentifier}: ${utilRes.status}`);
                    continue;
                }

                const utilData = await utilRes.json();
                const currentState = utilData.attributes.current_state;
                console.log(`[DEBUG] Server ${serverIdentifier} status: ${currentState}`);

                const now = Date.now();
                if (currentState === 'offline' && !isSuspended) {
                    if (!offlineServers[serverId]) {
                        console.log(`[SERVER] ${serverIdentifier} pertama kali offline.`);
                        offlineServers[serverId] = now;
                    } else {
                        const hoursOffline = Math.floor((now - offlineServers[serverId]) / 3600000);
                        console.log(`[SERVER] ${serverIdentifier} offline selama ${hoursOffline} jam.`);
                        if (hoursOffline >= 24) {
                            console.log(`[ACTION] Menghapus server ${serverIdentifier}...`);
                            await fetch(`${settings.domain}/api/application/servers/${serverId}`, {
                                method: "DELETE",
                                headers: { 'Authorization': `Bearer ${settings.plta}` }
                            });
                            
                            const serverName = server.attributes.name;
                            const message = `🚨 *SERVER DELETION NOTICE*\n\n` +
                                           `▸ Nama Server: ${serverName}\n` +
                                           `▸ ID Server: ${serverId}\n` +
                                           `▸ Alasan: Offline selama 24 jam`;
                            
                            adminUsers.forEach(adminId => {
                                bot.sendMessage(adminId, message, { parse_mode: 'Markdown' })
                                    .catch(error => console.error('Gagal kirim notifikasi:', error));
                            });
                            
                            delete offlineServers[serverId];
                        }
                    }
                } else {
                    if (offlineServers[serverId]) {
                        console.log(`[SERVER] ${serverIdentifier} kembali online.`);
                        delete offlineServers[serverId];
                    }
                }
            } catch (error) {
                console.error(`[ERROR] Gagal proses server ${serverIdentifier}:`, error);
            }
        }

        fs.writeFileSync(offlineServersFile, JSON.stringify(offlineServers));
        console.log('[CRON] Data offlineServers disimpan.');
    } catch (error) {
        console.error('[ERROR] Gagal di checkAndDeleteServers:', error);
    }
}

  cron.schedule('*/5 * * * *', () => {
      console.log('[CRON] Job dijalankan...');
      checkAndDeleteServers();
  });

function getSystemCpuUsage() {
    return new Promise((resolve) => {
        const start = cpuAverage();
        setTimeout(() => {
            const end = cpuAverage();
            const idleDiff = end.idle - start.idle;
            const totalDiff = end.total - start.total;
            const percentage = 100 - (100 * idleDiff / totalDiff);
            resolve(percentage.toFixed(2));
        }, 1000);
    });
}