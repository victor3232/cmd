/*
• Base Ori GhostXmods X WannOFFC
Penting ‼
*/

const settings = {
  token: '8065080964:AAGzfWUsSvvvsMfD5Ube11yxmqz1pg3w8IY',
  adminId: '1835508209',
  url_admin: 'https://t.me/kibiljoe',
  url_bot: 'https://t.me/bayarditempatbot',
  url_ch: 'https://t.me/hitsssh',
  domain: 'https://archellopublic.publicserver.my.id', 
  plta: 'ptla_JJ8y8PExPQPRPkJABLBRFcbcfnYA2dptpOoOMuv4Ncz', 
  pltc: 'ptlc_gLLn4TLFlZychedWHBLgoHXpBWfcFApMwHFfwxaBkjN', 
  pp: 'https://files.catbox.moe/ofz5ag.jpg',
  picture: 'https://files.catbox.moe/ofz5ag.jpg',
  ptero: 'https://files.catbox.moe/ofz5ag.jpg',
  loc: '1', 
  eggs: '15'
};

export default settings;